# Everyone loves grasshoppers, right? Complete the statement below so that the string "grasshopper" is
# printed by joining "grass" and "hopper".

print(write code here)

# My dog loves laying in front of the fireplace. I guess he just loves being a hot dog. Fix the statement below so that
# it correctly refers to my hot dog in front of the fireplace instead of the processed food product.

print(code here + "dog")

# How about ladybugs? They are fun little critters and they deserve to be mentioned. Complete the statement below
# so that "ladybug" is printed, but do this by joining each individual letter together (you should be joining 7 strings
# together with each string only containing one letter).

print(write code here)