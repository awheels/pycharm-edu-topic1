# Think back to when you were a little kid and you use to yell at your parents for your favourite teddy bear
# named 'Bartholomew'. I want you to yell 'Bartholomew!' over and over again 10 times.

print(write code here)