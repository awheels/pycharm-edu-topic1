# What if we wanted to print your height in feet and inches (5'10")?

print("I am height here tall")

# Now what if we wanted to list the height of several people in this format:
#
# Mr. Wheeler *tab* 5'10" *newline*
# Greg Smith *tab* 6'2" *newline*
# Emily Irk *ta* 5'5" *newline
#
# Fill in the placeholders below to achieve the format shown above.

print(Mr. Wheeler *tab* 5'10" *newline* Greg Smith *tab* 6'2" *newline* Emily Irk *tab* 5'5" *newline*)