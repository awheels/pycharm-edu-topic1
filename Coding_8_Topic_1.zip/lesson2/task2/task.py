print(string1, string2, string3)

print(string4, integer, float)