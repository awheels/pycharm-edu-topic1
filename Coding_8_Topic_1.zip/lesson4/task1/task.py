# Create a variable called fav_fruit and assign it a string.

fav_fruit = string

# Create a variable called num_fruit and assign it an integer representing how many of your
# fav_fruit you can eat in a single sitting.

num_fruit = integer

# Create a variable called cost_fruit and assign it a float representing the approximate cost of
# buying one of the fruit.

cost = float

# Create a variable called feel_sick and assign it a boolean representing if eating this many of the
# fruit will make you feel sick.

feels_sick = boolean

