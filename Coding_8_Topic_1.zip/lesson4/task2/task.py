# We will use the variable fav_number to store Mr. Wheeler's favourite number. Complete the print statement below
# so that it prints our Mr. Wheeler's favourite number.

fav_number = 5

print("Mr. Wheeler's favourite number is ", variable here)

# It is important to realize that we can always change the value of a variable. Update the fav_number variable below
# to your favourite number. If your favourite number is also 5, just pretend that it is actually a different number.

fav_number = your favourite number

print("My favourite number is ", fav_number)
