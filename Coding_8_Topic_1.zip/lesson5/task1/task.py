# Write an input function that asks the user what their name is.

write code here

# The input function will return the string the user enters. What if we want to save the string that the use enters?
# Write an input function that asks the user for their age and saves the value to a variable called 'age'.

write code here
