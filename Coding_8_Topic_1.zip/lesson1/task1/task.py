string = write code here

integer = write code here

float = write code here