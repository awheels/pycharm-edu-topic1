# Any line that starts with a # is a comment and is ignored by the computer.

you need to comment out
this or else your program
will fail

# print('uncomment this')
