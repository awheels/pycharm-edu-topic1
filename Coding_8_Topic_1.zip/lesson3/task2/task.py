addition = equation here

subtraction = equation here

multiplication = equation here

division = equation here

print(addition, subtraction, multiplication, division)