# Using exponents write two equations that both equal 16 (don't use the same equation for both)

exponent1 = equation here

exponent2 = equation here

print(exponent1, exponent2)