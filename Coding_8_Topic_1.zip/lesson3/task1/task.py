# This is review from lesson 1 but more practice is always a good thing (ok, maybe not always). Complete the statements
# below to print a integer and a float.

print(integer)

print(float)