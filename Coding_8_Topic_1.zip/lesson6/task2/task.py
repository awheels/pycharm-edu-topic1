# We can use the swapcase() method to, you guessed it, switch the case of each letter. Use swapcase() on the string below

string1 = "We wAnT TO swAp the caSe oF eacH lETTeR"

print(write code here)

# Use the replace() method to correct the error in the string below.

string2 = "Dr. McConnell is the Head of School at Stratford Hall."

print(write code here)