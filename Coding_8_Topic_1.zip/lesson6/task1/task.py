# User the string method upper() to print an uppercase version of the string below.

string = "Convert this string to all uppercase."

print(write code here)
