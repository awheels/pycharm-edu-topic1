# Can you use an augmented operator to increase x by a factor of 10?

x = 4
write code here

# Now use an augmented operator to decrease y by 3?

y = 4
write code here
