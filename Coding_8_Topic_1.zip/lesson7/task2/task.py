integer = '12'

float = '3.14'

string = 2015
