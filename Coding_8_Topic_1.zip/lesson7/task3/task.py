# Let's say that you wanted to increment x by 1. This would be one way of doing it:

x = 5
x = x + 1

# Can you use an augmented operator to increment y by 2?

y = 10
write code here
