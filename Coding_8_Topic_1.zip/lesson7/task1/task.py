# We are going to add two numbers together. Something is wrong with this code though, can you fix the code?

number1 = input("How many months in a year?")

number2 = input("How any seconds in a minute?")

print(number1 + number2)
